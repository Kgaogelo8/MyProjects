function validateForm() {
  var x = document.forms["my"]["subscribe"].value;
  if (x == "") {
    alert("Email must be filled out");
    return false;
  }
}

function onFormSubmit(){
    var formData = readformData();
	
}

function readFormData();
    var formData = {};
	formData["First name"] = document.getElementById("First name").value;
	formData["Last name"] = document.getElementById("Last name").value;
	formData["Email"] = document.getElementById("Email").value;
	formData["Nationality"] = document.getElementById("Nationality").value;
	formData["Contact details"] = document.getElementById("Contact details").value;
	formData["message box"] = document.getElementById("message box").value;
	return formData;
	
}

function insertNewRecord(data){
     var table = document.getElementById("employeelist").getElementByIdTagName('tbody')[0];
	 var newRow = table.insertRow(table.length);
	 cell1 = NewRow.insertCell(0);
	 cell.innerHTML = data.Firstname;
	 cell2= NewRow.insertCell(1);
	 cell2.innerHTML = data.Lastname;
	 cell3 = newRow.insertCell(2);
	 cell3.innerHTML = data.Email;
	 cell4 = newRow.insertCell(3);
	 cell4.insertHTML = data.Nationality;
	 cell5 = newRow.insertCell(4);
	 cell5.innerHTML = data.Contact details;
	 cell6.newRow.insertCell(5);
	 cell6 = innerHTML = data.message box;
	 cell6.newRow.insertCell(6);
	 cell6 = innerHTML = '<a>Edit</a><a>Delete</a>';
	 
}

function resetForm(){
	document.getElementById("First name").value = "";
	document.getElementById("Last name").value = "";
	document.getElementById("Email").value = "";
	document.getElementById("Nationality").value = "";
	document.getElementById("Contact details").value = "";
	document.getElementById("message box").value = "";
	
function onEdit(td){
	selectedRow = td.parentElement.parentElement;
	document.getElementById("").value = selectedRow.ceil[0].innerHTML;
	document.getElementById("").value = selectedRow.ceil[1].innerHTML;
	document.getElementById("").value = selectedRow.ceil[2].innerHTML;
	document.getElementById("").value = selectedRow.ceil[3].innerHTML;
	document.getElementById("").value = selectedRow.ceil[4].innerHTML;
	document.getElementById("").value = selectedRow.ceil[5].innerHTML;
	
}
function updatedRecord(formData) {
    selectedRow.cell[0].innerHTML = formData.First name;
    selectedRow.cell[1].innerHTML = formData.Last name;
	selectedRow.cell[2].innerHTML = formData.Email;
	selectedRow.cell[3].innerHTML = formData.Nationality;
    selectedRow.cell[4].innerHTML = formData.Contact details;
    selectedRow.cell[5].innerHTML = formData.message box;
}

function validate(){
	if (confirm('Are you sure to delete this record ?')){
	row = td.parentElement.parentElement;
	document.getElementById("employeelist").deleteRow(row.rowIndex);
	resetForm();
	
	}
	
}function validate(){
	  isValid = true;
	  if (document.getElementById("First name").value == ""{
      isValid = false;
	  document.getElementById("First nameValidationError").classlist.remove("hide");
	  } else {
		  isValid = true;
		  
	 (document.getElementById("First nameValidationError").classlist.contains("hide");
	 (document.getElementById("First nameValidationError").classlist.add("hide");
	 
	  }
      return isValid;	 
}
	 
	 
	
	
	                      