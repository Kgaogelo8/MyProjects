﻿namespace Fitness.Pages.Exercises
{
    internal class VideoModel
    {
        public string Title { get; internal set; }
        public string VideoUrl { get; internal set; }
        public string Level { get; internal set; }
    }
}