using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Fitness.Pages.Exercises
{
    public class ProgressModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
