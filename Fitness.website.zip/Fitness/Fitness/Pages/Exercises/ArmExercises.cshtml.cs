using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Fitness.Pages.Exercises
{
    public class ArmExercisesModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
