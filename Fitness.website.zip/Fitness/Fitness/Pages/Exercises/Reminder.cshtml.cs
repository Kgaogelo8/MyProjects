using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Fitness.Pages.Exercises
{
    public class ReminderModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
